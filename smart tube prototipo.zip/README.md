
  # smart tube prototipo

  This is a code bundle for smart tube prototipo. The original project is available at https://www.figma.com/design/d3segp44781iZGwXqXGva1/smart-tube-prototipo.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  